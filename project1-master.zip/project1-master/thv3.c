#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include "p1fxns.h"

void printUsage(char*);
int argPrefix(const char*,const char*);
void sigSet(int);

int signalSetup = 0;
static int debug = 0;

typedef struct pNode{
  pid_t pid;
  struct pNode* next;
} pNode;

typedef struct pQueue{
  pNode* front;
  pNode* rear;
  int count;
} pQueue;

int IsEmpty(pQueue*);

void Insert(pid_t item, pQueue* p){
  if(IsEmpty(p)){
    p->front = (pNode*) malloc(sizeof(pNode));
    p->rear = p->front;
    p->front->pid = item;
    p->front->next = NULL;
    p->count++;
  }
  else{
    p->rear->next = (pNode*) malloc(sizeof(pNode));
    p->rear = p->rear->next;
    p->rear->pid = item;
    p->rear->next = NULL;
    p->count++;
  }
}

pid_t Remove(pQueue* p){
  pid_t returnval = p->front->pid;
  pNode* temp = p->front;
  p->front = p->front->next;
  free(temp);
  p->count--;
  return returnval;
}

int IsEmpty(pQueue* p){
  if (p->front == NULL && p->rear == NULL)
    return 1;
  return 0;
}

static pQueue processQueue;
static pid_t running;

void timer_handler(int);

int main(int argc, char* argv[])
{
  struct timeval start;
  gettimeofday(&start, NULL);
  char* command = NULL;
  int processes = 0;
  int processors = 0;
  int i; //Default iterator
  char* buffer = (char*)malloc(sizeof(char) * 256); //Default buffer

  char* envCheck;
  envCheck = getenv("TH_NPROCESSES");
  if(envCheck == NULL)
    setenv("TH_NPROCESSES", "1", 0);
  envCheck = getenv("TH_NPROCESSORS");
  if(envCheck == NULL)
    setenv("TH_NPROCESSORS", "1", 0);

  if (argc < 2 || argc > 4){
    printUsage((char*)"Invalid number of commands");
    free(buffer);
    return -1;
  }

  //TODO Ensure decimals arnt entered
  for(i = 1; i < argc ; i++)
  {
    if(argPrefix(argv[i], (char*)"--number="))
      processes = p1atoi(argv[i]+p1strlen((char*)"--number="));
    else if(argPrefix(argv[i], (char*)"--processors="))
	    processors = p1atoi(argv[i]+p1strlen((char*)"--processors="));
    else if(argPrefix(argv[i], (char*)"--command=")){
	    p1strcpy(buffer, argv[i]+p1strlen((char*)"--command="));
      command = (char*) malloc(sizeof(char) * p1strlen(buffer) + 1);
      p1strcpy(command, buffer);
    }
    else{
        p1strcat(buffer, (char*)"Invalid argument given: \"");
        p1strcat(buffer, argv[i]);
        p1strcat(buffer, (char*)"\" ");
        if(buffer[0] == 0)
          for (int i2 = 1; i2 < p1strlen(buffer); i2++)
            buffer[i2 - 1] = buffer[i2];
        printUsage(buffer);
        free(buffer);
        return -1;
    }
  }
  buffer[0] = 0;
  if (command == NULL){
      printUsage((char*)"No command given");
      free(buffer);
      return -1;
  }

  if (processes < 1)
  {
    char* s = getenv("TH_NPROCESSES");
    if(s != NULL)
      processes = p1atoi(s);
    else{
      //processes env var not set (should have been set error)
      free(buffer);
      return -1;
    }
  }
  if (processors < 1)
  {
    char* s = getenv("TH_NPROCESSORS");
    if(s != NULL)
      processors = p1atoi(s);
    else{
      //processer env var not set (should have been set error)
      free(buffer);
      return -1;
    }
  }
  if(processes < 1 || processors < 1){
    printUsage((char*)"Invalid processes or processsor range");
    free(buffer);
    return -1;
  }

  //For getting the position of parsing the command string
  int pos = 0;
  //Assemble the nessiary minimum null arg list, the command and a null arg
  char** args = (char**)malloc(sizeof(char*) * 2);
  pos = p1getword(command, pos, buffer);//Get command
  args[0] = (char*)malloc(sizeof(char) * p1strlen(buffer) + 1);
  p1strcpy(args[0], buffer);
  args[1] = NULL; //Null terminate

  buffer[0] = 0;
  //While there is a next argument, create a new arg element, push the null back
  i = 1;
  while(command[pos] != '\0')
  {
    pos = p1getword(command, pos, buffer);
    args[i] = (char*)malloc(sizeof(char) * p1strlen(buffer) + 1);
    p1strcpy(args[i], buffer);
    args = (char**)realloc(args, sizeof(char*) * (++i + 1)); //Indexer -> count and add one
    args[i] = NULL; //Last element is null
  }

  buffer[0] = 0;
  //Now the executing program, arguments, processor and processes is ready to
  //Fork the process
  pid_t pid[processes];

  for(int i = 0; i < processes; i++)
  {
    signal(SIGUSR1, sigSet); //Set up signal handler for children
    pid[i] = fork();
    if (pid[i] < 0){
      //WARNING BAD FORK
      free(buffer);
      if(command != NULL)
        free(command);
      i=0;
      do{
        free(args[i++]);
      }while(args[i]!= NULL);
      if(args != NULL)
        free(args);
      return -1;
    }
    if(pid[i] == 0){
      while(!signalSetup){
        pause();
      }
      execvp(args[0], args);
    }
  }
  signal(SIGUSR1, SIG_IGN); //Disable handler for parent

  for(i = 0; i < processes; i++){
    Insert(pid[i], &processQueue);
    p1putstr(2, "Inserted pid ");
    p1itoa(pid[i], buffer);
    p1putstr(2, buffer);
    p1putstr(2, "\n");
  }

  //SIG ALARM ACTION HEAVILY GOTTEN FROM informit.com
  struct sigaction sa;
  struct itimerval timer;

  sa.sa_handler = &timer_handler;
  sigaction(SIGVTALRM, &sa, NULL);

  timer.it_value.tv_sec = 0;
  timer.it_value.tv_usec = 250000;

  timer.it_interval.tv_sec = 0;
  timer.it_interval.tv_usec = 250000;

  setitimer(ITIMER_VIRTUAL, &timer, NULL);

  for(i = 0; i < processes; i++){
    p1putstr(2, "Starting pid ");
    p1itoa(pid[i], buffer);
    p1putstr(2, buffer);
    p1putstr(2, "\n");
    kill(pid[i], SIGUSR1);
  }

  for(int i = 0; i < processes; i++){
    p1putstr(2, "waiting on pid ");
    p1itoa(pid[i], buffer);
    p1putstr(2, buffer);
    p1putstr(2, "\n");
    wait(&pid[i]);
  }

  struct timeval end;
  gettimeofday(&end, NULL);

  buffer[0] = 0;
  p1putstr(1 , (char*)"The elapsed time to execute ");
  p1itoa(processes, buffer);
  p1putstr(1 , buffer);
  p1putstr(1, (char*)" copies of \"");
  p1putstr(1, command);
  p1putstr(1, (char*)"\" on ");
  p1itoa(processors, buffer);
  p1putstr(1, buffer);
  p1putstr(1, (char*)" processors is ");
  int secs = (((end.tv_sec - start.tv_sec)*1000000L + end.tv_usec) - start.tv_usec)/1000000;
  int msecs = (((end.tv_sec - start.tv_sec)*1000000L + end.tv_usec) - start.tv_usec)/1000 - secs * 1000;

  // double remainderTime = timeTaken % 1;
  p1itoa(secs, buffer);
  p1putstr(1, buffer);
  p1putstr(1, (char*)".");
  if(msecs < 100){
    p1putstr(1,(char*)"0");
    if(msecs < 10)
      p1putstr(1, (char*)"0");
  }
  p1itoa(msecs, buffer);
  p1putstr(1, buffer);

  p1itoa(debug, buffer);
  p1putstr(1, (char*)"\n");
  p1putstr(1, buffer);
  //Free Block
  free(buffer);
  if(command != NULL)
    free(command);
  i=0;
  do{
    free(args[i++]);
  }while(args[i]!= NULL);
  if(args != NULL)
    free(args);
}

void timer_handler(int signum)
{
  p1putstr(2, "In alarm handler");
  kill(running, SIGSTOP);
  Insert(running, &processQueue);
  running = Remove(&processQueue);
  kill(running, SIGCONT);
  debug++;
}

//Throw away function for future need of child processes on starting exec
void sigSet(int sig)
{
  signalSetup = 1;
}

//Returns True if the expected string is the same as beginning of the argument string
int argPrefix(const char* as, const char* es)
{
  while (*es)
    if(*es++ != *as++)
      return 0;
  return 1;
}

void printUsage(char* s)
{
  char display[256];
  p1strcat(display, (char*)"Error: ");
  p1strcat(display, s);
  p1strcat(display, (char*)"\nUsage ./thv_ [--number=<nprocesses>] [--processors=<nprocessors>] –-command=’command’\n");
  p1putstr(2, display);
}
